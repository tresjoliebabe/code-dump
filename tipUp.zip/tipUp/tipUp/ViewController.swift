//
//  ViewController.swift
//  tipUp
//
//  Created by NicoleA on 2/20/17.
//  Copyright © 2017 Agetas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tipUPView: UIView!
    @IBOutlet weak var billField: UITextField!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tipControl: UISegmentedControl!
    @IBOutlet weak var madMoneyImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        updateDefaultUIPercentage(tipControl)
        //set all fields to $0.00
        initUIValues()
        getUIDefaults()
        
        // Center control
        tipControl.center = view.center
    
        print("View did load...")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //animating fields
        billField.center.x  -= view.bounds.width
        tipLabel.center.x -= view.bounds.width
        totalLabel.center.x -= view.bounds.width
        tipControl.center.x -= view.bounds.width
        
        //make keyboard always appear
        billField.becomeFirstResponder()
        updateDefaultUIPercentage(tipControl)
        getUIDefaults()
        calculateTip(Any.self)
        totalLabel.layer.masksToBounds=true
        totalLabel.layer.cornerRadius=4
        tipControl.layer.masksToBounds=true
        tipControl.layer.cornerRadius=4
        
        print("View will appear...")
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        updateDefaultUIPercentage(tipControl)
        getUIDefaults()
        calculateTip(Any.self)
        
        //animation
        UIView.animate(withDuration: 0.3) {
            self.billField.center.x += self.view.bounds.width
        }
        UIView.animate(withDuration: 0.3, delay: 0.1, options: [],
                       animations: {
                        self.tipLabel.center.x += self.view.bounds.width
        }, 
                       completion: nil
        )
        UIView.animate(withDuration: 0.3, delay: 0.2, options: [],
                       animations: {
                        self.totalLabel.center.x += self.view.bounds.width
        }, 
                       completion: nil
        )
        UIView.animate(withDuration: 0.3, delay: 0.2, options: [],
                       animations: {
                        self.tipControl.center.x += self.view.bounds.width
        },
                       completion: nil
        )
        print("View did appear...")
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("View will disappear...")
        setUIDefaults()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("View did disappear...")
        setUIDefaults()
        //start timing
        let defaults = UserDefaults.standard
        defaults.set(Date(), forKey:"StartTime")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*func setUIDefaults(){
        let defaults = UserDefaults.standard
        defaults.set(0.0, forKey: "TipDefault")
        defaults.set(0.0, forKey: "TotalDefault")
    }
    
     func getUIDefaults(){
     let defaults = UserDefaults.standard
     let tipDefault = defaults.double(forKey:"TipDefault")
     let totalDefault = defaults.double(forKey:"TotalDefault")
     
     tipLabel.text = String(format: "$%.2f", tipDefault)
     totalLabel.text = String(format: "$%.2f", totalDefault)
    }*/
    
    func initUIValues(){let defaults = UserDefaults.standard
        defaults.set("$0.00", forKey: "TipDefault")
        defaults.set("$0.00", forKey: "TotalDefault")
        defaults.set("", forKey:"BillDefault")
        defaults.set(Date(), forKey:"StartTime")
    }
    
    func setUIDefaults(){
        let defaults = UserDefaults.standard
        defaults.set(billField.text, forKey:"BillDefault")
        defaults.set(tipLabel.text, forKey: "TipDefault")
        defaults.set(totalLabel.text, forKey: "TotalDefault")
    }
    
    func getUIDefaults(){
        let defaults = UserDefaults.standard
        let billDefault = defaults.string(forKey:"BillDefault")
        let startTime = defaults.object(forKey:"StartTime") as! Date
        let now = Date()
        let interval = now.timeIntervalSince(startTime)
        let tipDefault = defaults.string(forKey:"TipDefault")
        let totalDefault = defaults.string(forKey:"TotalDefault")
        //print("interval: ",interval)
        
        //interval less than 10 mins
        if (interval < 600.0){
            billField.text = billDefault
            tipLabel.text = tipDefault
            totalLabel.text = totalDefault
        }
        else{
            billField.text = ""
            tipLabel.text = "$0.00"
            totalLabel.text = "$0.00"
        }
        
        updateUIThemeColor()
    }
    
    @IBAction func onTap(_ sender: Any) {
        view.endEditing(true)
    }

    @IBAction func updateDefaultUIPercentage(_ sender: UISegmentedControl) {
        
        let defaults = UserDefaults.standard
        let tipValue = defaults.double(forKey: "defaultPercentValue")
        
        if (tipValue == 0.18){
            sender.selectedSegmentIndex = 0
        }
        else if (tipValue == 0.2){
            sender.selectedSegmentIndex = 1
        }
        else if (tipValue == 0.25){
            sender.selectedSegmentIndex = 2
        }
    }

    @IBAction func calculateTip(_ sender: Any) {
        let tipPercentages = [0.18, 0.2, 0.25]
        
        let bill = Double(billField.text!) ?? 0
        let tip = bill * tipPercentages[tipControl.selectedSegmentIndex]
        let total = bill + tip
        
        //tipLabel.text = String(format: "$%.2f", tip)
        //totalLabel.text = String(format: "$%.2f", total)
        tipLabel.text = formatLocatCurrency(doubleAmount: tip)
        totalLabel.text = formatLocatCurrency(doubleAmount: total)
    }
    
    //This function sets the locale-specific currency
    //and currency thousands separator
    func formatLocatCurrency (doubleAmount: Double) -> String{
        let amount = doubleAmount as NSNumber
        let currencyFormatter = NumberFormatter()
        currencyFormatter.usesGroupingSeparator = true //currency thousands separator
        currencyFormatter.numberStyle = .currency
        currencyFormatter.locale = Locale.current //localizes currency
        let currencyString = currencyFormatter.string(from: amount)
        //print("USD: ", (currencyString)!) // Displays $US.00
        return currencyString!
    }
    
    func updateUIThemeColor() {
        let defaults = UserDefaults.standard
        let themeColor = defaults.string(forKey: "ThemeColorValue") ?? "Light"
        
        if(themeColor=="Dark"){
            //set dark theme
            let darkTheme = UIColor(red: 139.0/255.0, green: 99.0/255.0, blue: 55.0/255.0, alpha: 1.0)
            self.view.backgroundColor = darkTheme
            madMoneyImage.isHidden = true
        }
        else if(themeColor=="Light"){
            let lightTheme = UIColor(red: 255.0/255.0, green: 240.0/255.0, blue: 197/255.0, alpha: 1.0)
            self.view.backgroundColor = lightTheme
            madMoneyImage.isHidden = false
        }
        
    }

    
}

