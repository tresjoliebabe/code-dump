//
//  ViewController.swift
//  tipUp
//
//  Created by NicoleA on 2/20/17.
//  Copyright © 2017 Agetas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tipUPView: UIView!
    @IBOutlet weak var billField: UITextField!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tipControl: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        updateDefaultUIPercentage(tipControl)
        //set all fields to $0.00
        setUIDefaults()
        getUIDefaults()
        
        // Center control
        tipControl.center = view.center
        
        // animation
        self.tipUPView.alpha = 0
        UIView.animate(withDuration: 0.4, animations: {
            self.tipUPView.alpha = 1 })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateDefaultUIPercentage(tipControl)
        //set all fields to $0.00
        getUIDefaults()
        print("View will appear...")
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        updateDefaultUIPercentage(tipControl)
        //set all fields to $0.00
        getUIDefaults()
        print("View did appear...")
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("View will disappear...")
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("View will disappear...")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func setUIDefaults(){
        let defaults = UserDefaults.standard
        defaults.set(0.0, forKey: "tipDefault")
        defaults.set(0.0, forKey: "totalDefault")
    }
    
    func getUIDefaults(){
        let defaults = UserDefaults.standard
        let tipDefault = defaults.double(forKey:"tipDefault")
        let totalDefault = defaults.double(forKey:"totalDefault")
        
        tipLabel.text = String(format: "$%.2f", tipDefault)
        totalLabel.text = String(format: "$%.2f", totalDefault)
        billField.text = ""
    }
    
    @IBAction func onTap(_ sender: Any) {
        view.endEditing(true)
    }

    @IBAction func updateDefaultUIPercentage(_ sender: UISegmentedControl) {
        
        let defaults = UserDefaults.standard
        let tipValue = defaults.double(forKey: "defaultPercentValue")
        
        if (tipValue == 0.18){
            sender.selectedSegmentIndex = 0;
        }
        else if (tipValue == 0.2){
            sender.selectedSegmentIndex = 1;
        }
        else if (tipValue == 0.25){
            sender.selectedSegmentIndex = 2;
        }
    }

    @IBAction func calculateTip(_ sender: Any) {
        let tipPercentages = [0.18, 0.2, 0.25]
        
        let bill = Double(billField.text!) ?? 0
        let tip = bill * tipPercentages[tipControl.selectedSegmentIndex]
        let total = bill + tip
        
        tipLabel.text = String(format: "$%.2f", tip)
        totalLabel.text = String(format: "$%.2f", total)
    }
}

