//
//  SettingsViewController.swift
//  tipUp
//
//  Created by NicoleA on 2/21/17.
//  Copyright © 2017 Agetas. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    @IBOutlet var settingsView: UIView!
    @IBOutlet weak var tipSettingControl: UISegmentedControl!
    @IBOutlet weak var themeSettingControl: UISegmentedControl!
    @IBOutlet weak var currencySettingControl: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        updateUIPercentageSetting(tipSettingControl)
        updateUIThemeColor(themeSettingControl)
        updateCurrencySetting(currencySettingControl)
        
        // Center control
        tipSettingControl.center = view.center
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateUIPercentageSetting(tipSettingControl)
        updateUIThemeColor(themeSettingControl)
        updateCurrencySetting(currencySettingControl)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        updateUIPercentageSetting(tipSettingControl)
        updateUIThemeColor(themeSettingControl)
        updateCurrencySetting(currencySettingControl)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        setDefaultPercentage(self)
        setThemeColor(self)
        setCurrency(self)
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        setDefaultPercentage(self)
        setThemeColor(self)
        setCurrency(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func setDefaultPercentage(_ sender: Any) {
        let tipSettingPercentages = [0.18, 0.2, 0.25]
        
        let defaultPercent = tipSettingPercentages[tipSettingControl.selectedSegmentIndex]
        
        let defaults = UserDefaults.standard
        defaults.set(defaultPercent, forKey: "defaultPercentValue")
    }
    
    @IBAction func updateUIPercentageSetting(_ sender: UISegmentedControl) {
        //set default tip
        let defaults = UserDefaults.standard
        
        let tipValue = defaults.double(forKey: "defaultPercentValue")
        
        if (tipValue == 0.18){
            sender.selectedSegmentIndex = 0
        }
        else if (tipValue == 0.2){
            sender.selectedSegmentIndex = 1
        }
        else if (tipValue == 0.25){
            sender.selectedSegmentIndex = 2
        }        
    }
    
    @IBAction func updateCurrencySetting(_ sender: UISegmentedControl) {
        let defaults = UserDefaults.standard
        
        let currencyType = defaults.string(forKey: "DefaultCurrency")
        if (currencyType == "$"){
            sender.selectedSegmentIndex = 0
        }
        if (currencyType == "€"){
            sender.selectedSegmentIndex = 1
        }
    }
    
    @IBAction func setThemeColor(_ sender: Any) {
        let themeColors = ["Dark", "Light"]
        
        let defaultThemeColor = themeColors[themeSettingControl.selectedSegmentIndex]
        let defaults = UserDefaults.standard
        defaults.set(defaultThemeColor, forKey: "ThemeColorValue")
    }
    
    @IBAction func setCurrency(_ sender: Any) {
        let currencyOptions = ["$", "€"]
       
        let defaultCurrency = currencyOptions[currencySettingControl.selectedSegmentIndex]
        let defaults = UserDefaults.standard
        defaults.set(defaultCurrency, forKey: "DefaultCurrency")
    }
    
    @IBAction func updateUIThemeColor(_ sender: UISegmentedControl) {
        let defaults = UserDefaults.standard
        let themeColor = defaults.string(forKey: "ThemeColorValue")
        
        if(themeColor=="Dark"){
            //set dark theme
            //let darkTheme = UIColor(red: 139.0/255.0, green: 99.0/255.0, blue: 55.0/255.0, alpha: 1.0)
            let darkTheme = UIColor.black
            tipSettingControl.layer.masksToBounds=true
            tipSettingControl.layer.cornerRadius=4
            themeSettingControl.layer.masksToBounds=true
            themeSettingControl.layer.cornerRadius=4
            currencySettingControl.layer.masksToBounds=true
            currencySettingControl.layer.cornerRadius=4
            self.view.backgroundColor = darkTheme
            sender.selectedSegmentIndex = 0
        }
        else if(themeColor=="Light"){
            let lightTheme = UIColor(red: 255.0/255.0, green: 240.0/255.0, blue: 197/255.0, alpha: 1.0)
            self.view.backgroundColor = lightTheme
            sender.selectedSegmentIndex = 1
        }        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
